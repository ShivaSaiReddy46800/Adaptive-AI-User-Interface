import tkinter as tk
import json
import os
DATA_FILE = "user_preferences.json"

# Default preferences
default_preferences = {
    "theme": "light",
    "font_size": 14
}

def load_preferences():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as file:
            return json.load(file)
    return default_preferences


def save_preferences(prefs):
    with open(DATA_FILE, "w") as file:
        json.dump(prefs, file)


preferences = load_preferences()

# Apply theme settings
def apply_theme():
    if preferences["theme"] == "dark":
        root.configure(bg="black")
        label.configure(bg="black", fg="white")
    else:
        root.configure(bg="white")
        label.configure(bg="white", fg="black")


def set_dark_mode():
    preferences["theme"] = "dark"
    save_preferences(preferences)
    apply_theme()


def set_light_mode():
    preferences["theme"] = "light"
    save_preferences(preferences)
    apply_theme()


def increase_font():
    preferences["font_size"] += 2
    label.config(font=("Arial", preferences["font_size"]))
    save_preferences(preferences)


def decrease_font():
    preferences["font_size"] -= 2
    label.config(font=("Arial", preferences["font_size"]))
    save_preferences(preferences)


# GUI Window
root = tk.Tk()
root.title("AI Adaptive User Interface")
root.geometry("500x300")

label = tk.Label(
    root,
    text="Welcome to the Adaptive AI Interface",
    font=("Arial", preferences["font_size"])
)

label.pack(pady=30)

dark_button = tk.Button(root, text="Dark Mode", command=set_dark_mode)
dark_button.pack(pady=5)

light_button = tk.Button(root, text="Light Mode", command=set_light_mode)
light_button.pack(pady=5)

increase_button = tk.Button(root, text="Increase Font Size", command=increase_font)
increase_button.pack(pady=5)

decrease_button = tk.Button(root, text="Decrease Font Size", command=decrease_font)
decrease_button.pack(pady=5)

apply_theme()

root.mainloop()